export interface CarWallpaper {
  id: string;
  title: string;
  brand: string;
  category: 'Supercar' | 'Hypercar' | 'Classic' | 'Off-road' | 'Luxury';
  imageUrl: string;
  resolution: string;
}

export const CAR_WALLPAPERS: CarWallpaper[] = [
  {
    id: '1',
    title: 'Neon Nights Aventador',
    brand: 'Lamborghini',
    category: 'Supercar',
    imageUrl: 'https://images.unsplash.com/photo-1544636331-e16877ffb31a?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '2',
    title: 'Sleek Porsche 911',
    brand: 'Porsche',
    category: 'Supercar',
    imageUrl: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '3',
    title: 'McLaren P1 Dusk',
    brand: 'McLaren',
    category: 'Hypercar',
    imageUrl: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '4',
    title: 'Defender Summit',
    brand: 'Land Rover',
    category: 'Off-road',
    imageUrl: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '5',
    title: 'Bugatti Chiron Speed',
    brand: 'Bugatti',
    category: 'Hypercar',
    imageUrl: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '6',
    title: 'Vintage Ferrari 250',
    brand: 'Ferrari',
    category: 'Classic',
    imageUrl: 'https://images.unsplash.com/photo-1592198084033-aade902d1aae?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '7',
    title: 'Rolls Royce Phantom',
    brand: 'Rolls Royce',
    category: 'Luxury',
    imageUrl: 'https://images.unsplash.com/photo-1631215539199-fd8241315570?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '8',
    title: 'G-Wagon Night Edition',
    brand: 'Mercedes',
    category: 'Off-road',
    imageUrl: 'https://images.unsplash.com/photo-1520031441872-265e4ff70366?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '9',
    title: 'Aston Martin Vantage',
    brand: 'Aston Martin',
    category: 'Luxury',
    imageUrl: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '10',
    title: 'Dodge Challenger Smoke',
    brand: 'Dodge',
    category: 'Supercar',
    imageUrl: 'https://images.unsplash.com/photo-1603386329225-868f9b1ee6c9?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '11',
    title: 'Audi R8 Glow',
    brand: 'Audi',
    category: 'Supercar',
    imageUrl: 'https://images.unsplash.com/photo-1606148632319-3e3e0c0a8f89?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '12',
    title: 'Shelby Cobra Rally',
    brand: 'Ford',
    category: 'Classic',
    imageUrl: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&q=80&w=2560',
    resolution: '3840 x 2160',
  },
  {
    id: '13',
    title: 'Mclaren 720S',
    brand: 'Mclaren',
    category: 'Supercar',
    imageUrl: 'https://images.unsplash.com/photo-1542362567-b07e54358753?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    resolution: '3840 x 2160',
  }
];

export const CATEGORIES = ['All', 'Supercar', 'Hypercar', 'Classic', 'Off-road', 'Luxury','JDM'] as const;
